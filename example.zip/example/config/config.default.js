console.log('config.default lauched!');

'use strict';

module.exports = appInfo => {
    const config = exports = {};

    config.keys = "wangyao-secert";

    // 配置中间件（添加printdate.js去掉后缀
    // config.middleware = ['printdate', 'forbidip'];    
    
    // 给 printdate 中间件传入参数（配置 options）
    //config.printdate = {parm:'1234'};
    config.forbidip = {
        forbiddenip:[
            '127.0.0.1',
            '10.183.146.167'
        ]
    }

    config.view = {
        mapping: {
            '.html':'ejs',
        },
    };

    config.security = {
        csrf: {
          enable: false,
        }
    }

    return config;
};